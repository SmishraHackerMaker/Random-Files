


API_ID: int = int(25367618)

API_HASH: str = str("7c434192dd12bfb05089ec2c424ff11c")

SESSION_STRING: str = str("BQGDFEIASdRvZh-hPML7hSMsMUgZLO3d_6lXZLjCkufYkvnW2mxMYZyjqGYJS516fQMRg3Aql_Cvbl2fhbCtsz6mgomVjydSLAOEKZdfXxQWxcQ6gve3DBmQhya1Ve9kR1Ikjrw3w_F4und5Ox-DPSDhuWT4iIxyW8i5F9zwJKplPrlWTf-9hyPBBc3nyYS1u9utahMHL0MX56JfL-H_4mX6p3sqnynvRLCO0dvE1By68FEzBIGZWegeNVz9A61FezxSW6wXRiCZNqPJSmfq2cEpZRPW_dL8_0sQhTqHrd0XQoTJzhqmmIkS_zdwrc4b18Fkqc8v0WLsJ9tEAgKVCuqztiKUVwAAAAFLoeK_AA")

OWNER_ID: list[int] = [5563867839, 1796596300, 971831558]

LOG_GROUP_ID: int = int(-1001781612088)

PREFIX: str = str(".")

RPREFIX: str = str("$")


# No Need To Edit Below This

LOG_FILE_NAME: str = "YMusic.txt"