from YMusic import call
from pytgcalls.types.input_stream import AudioPiped, AudioVideoPiped
from pytgcalls import StreamType


audio_file = "http://docs.evostream.com/sample_content/assets/sintel1m720p.mp4"


async def play(chat_id, audio_file=audio_file):
	try :
		await call.join_group_call(
			chat_id,
			AudioVideoPiped(
				audio_file,
			),
			stream_type=StreamType().pulse_stream,
		)
		return "Success"
	except Exception as e :
		return f"Error:- <code>{e}</code>"


async def stop(chat_id):
	try :
		await call.leave_group_call(
			chat_id,
		)
		return "Success"
	except Exception as e :
		return f"Error:- <code>{e}</code>"