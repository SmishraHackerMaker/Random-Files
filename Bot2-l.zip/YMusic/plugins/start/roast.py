


from pyrogram import filters
import random

from YMusic import app
from YMusic.core import userbot
import config
from YMusic.utils.roast.data import REPLYRAID

PREFIX = config.PREFIX

ROAST_COMMAND = "ROAST"

@app.on_message(filters.command(ROAST_COMMAND, PREFIX) & filters.me)
async def _fuck(_, message) :
	if message.reply_to_message_id is not None :
		roastTime = 10
		chat_id = msg.chat.id
		msg_id = message.reply_to_message_id
		for i in range(roastTime) :
			Text = radom.choice(REPLYRAID)
			await send_msg(chat_id, msg_id, Text)
	else :
		message.reply_text("Abe roast kisko karna hai\nUsko tag karke ye command run kar")

	
async def send_msg(chat_id, msg_id, Text) :
	await app.send_message(
	    chat_id=chat_id,
	    text=Text,
	    reply_to_message_id=msg_id
	)	
		


