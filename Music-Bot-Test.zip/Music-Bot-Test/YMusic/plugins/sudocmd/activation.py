
from pyrogram import filters

from YMusic import app
from YMusic.misc import SUDOERS, chatBotActive

import config

RPREFIX = config.RPREFIX
CHATBOTCOMMAND = ["CHATBOT"]



chatBotUsage = f"ChatBot Command Usage:-\n\n{RPREFIX} on - To turn on the chatbot\n{RPREFIX} off - To turn off the chatbot"





@app.on_message(filters.command(CHATBOTCOMMAND, RPREFIX) & SUDOERS)
async def _chatBot(_, message) :
	if len(message.command) < 2 :
		await message.reply_text(chatBotUsage)
		return
	
	hint = ((message.text).split()[1]).lower()
	if hint == "on" :
		if chatBotActive :
			await message.reply_text("Chat Bot Is Already On")
		else :
			chatBotActive = True
			await message.reply_text("ChatBot Turned On Successfully")
	elif hint == "off" :
		if not chatBotActive :
			await message.reply_text("Chat Bot Is Already Off")
		else :
			chatBotActive = False
			await message.reply_text("ChatBot Turned Off Successfully")
	else :
		await message.reply_text(chatBotUsage)



