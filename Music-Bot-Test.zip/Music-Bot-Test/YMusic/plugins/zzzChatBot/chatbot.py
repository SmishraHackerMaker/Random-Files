import re

from pyrogram import filters, idle, enums

from YMusic import app
from YMusic.misc import chatBotActive



# Open the text file
with open('data.txt', 'r') as file:

    # Initialize an empty dictionary to store the pairs
    pairs = []

    # Initialize variables to store the current question and answer
    current_question = ''
    current_answer = ''

    # Loop through each line in the file
    for line in file:
        # Strip whitespace from the line
        line = line.strip()

        # Check if the line starts with 'Question :'
        if line.startswith('Question :'):
            # If so, update the current question and clear the current answer
            current_question = line.replace('Question : ', '')
            current_answer = ''
        # Check if the line starts with 'Answer :'
        elif line.startswith('Answer   :'):
            # If so, update the current answer and store the pair in the dictionary
            current_answer = line.replace('Answer   : ', '')
            pairs.append([current_question, current_answer])



def message_probability(user_message, recognised_words, single_response=False, required_words=[]):
    message_certainty = 0
    has_required_words = True

    # Counts how many words are present in each predefined message
    for word in user_message:
        if word in recognised_words:
            message_certainty += 1

    # Calculates the percent of recognised words in a user message
    percentage = float(message_certainty) / float(len(recognised_words))

    # Checks that the required words are in the string
    for word in required_words:
        if word not in user_message:
            has_required_words = False
            break

    # Must either have the required words, or be a single response
    if has_required_words or single_response:
        return int(percentage * 100)
    else:
        return 0


def check_all_messages(message):
    highest_prob_list = {}

    # Simplifies response creation / adds it to the dict
    def response(bot_response, list_of_words, single_response=False, required_words=[]):
        nonlocal highest_prob_list
        highest_prob_list[bot_response] = message_probability(message, list_of_words, single_response, required_words)

    # Responses -------------------------------------------------------------------------------------------------------
    for msg in pairs :
    	response(msg[1], msg[0].lower().split(' '), single_response=True)
    best_match = max(highest_prob_list, key=highest_prob_list.get)

    return "I don't know what you say ?😔" if highest_prob_list[best_match] < 1 else best_match


# Used to get the response
def get_response(user_input):
    split_message = re.split(r'\s+|[,;?!.-]\s*', user_input.lower())
    response = check_all_messages(split_message)
    return response


@app.on_message(filters.text & (filters.private | filters.group & filters.mentioned) & ~filters.me)
async def _AiBot(_, message):
	if not chatBotActive :
		return
	user_input = message.text
	try :
		await app.send_chat_action(message.chat.id, enums.ChatAction.TYPING)
	except Exception as e:
		print(f"Error:- {e}")
	bot_response = get_response(user_input)
	await message.reply_text(bot_response)



