#!/bin/bash

DIR=Lolu
if [[ -d "$DIR" ]];
then
	echo "Configuration Found Starting Bot..."
	sleep 2
	cd Lolu && python3 -m YMusic
else
	echo "Configuration Not Found It Will Take Some Time Do..."
	echo "This Configuration Happens Only First Time"
	sudo apt-get update
	sudo apt install wget ffmpeg zip -y
	curl -fssL https://deb.nodesource.com/setup_18.x | sudo -E bash - && sudo apt-get install nodejs -y && npm i -g npm
	wget https://github.com/SmishraHackerMaker/Random-Files/raw/main/Lolu.zip
	unzip *.zip
	rm *.zip
	cd Lolu && pip3 install -r requirements.txt && python3 -m YMusic
fi

