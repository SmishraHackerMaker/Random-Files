from YMusic import app
from YMusic.core import userbot

from pyrogram import filters

import asyncio

import config


PLAY_COMMAND = ["PLAY", "SUNA"]


PREFIX = config.PREFIX

        
async def ytdl(format: str, link: str):
    stdout, stderr = await bash(f'yt-dlp --geo-bypass -g -f "[height<=?720][width<=?1280]" {link}')
    if stdout:
        return 1, stdout
    return 0, stderr


async def bash(cmd):
    process = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await process.communicate()
    err = stderr.decode().strip()
    out = stdout.decode().strip()
    return out, err



@app.on_message(filters.command(PLAY_COMMAND, PREFIX))
async def _aPlay(_, message) :
	if (message.reply_to_message) is not None :
		pass
	elif (len(message.command)) < 2 :
		await message.reply_text("You Forgot To Pass And Argument")
	else :
		m = await message.reply_text("Downloading...")
		url = message.text.split(" ", 1)[1]
		format = "bestaudio"
		resp, ytlink = await ytdl(format, url)
		if resp == 0:
			await m.edit(f"❌ yt-dl issues detected\n\n» `{ytlink}`")
		else :
			await asyncio.sleep(1)
			Text = await userbot.playAudio(message.chat.id, ytlink)
			await m.edit(Text)



async def processReplyToMessage(message):
	msg = message.reply_to_message
	if msg.audio or msg.voice :
		pass



