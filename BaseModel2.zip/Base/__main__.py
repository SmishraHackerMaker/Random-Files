

from pyrogram import idle, compose
from pyrogram.errors import RPCError
from Base import app

import sys
import asyncio

loop = asyncio.get_event_loop()

mySelf = None

async def init() :
	try :
		await app.start()
		mySelf = await app.get_me()
		print(f"Bot Started as {mySelf.first_name}")
		await app.stop()
		# await idle()
		await compose([app])
	except RPCError as rip :
		print(f"Error:- {rip}")
		sys.exit()
	
	except Exception as error :
		print(error)
		sys.exit()


if __name__ == "__main__" :
	# loop.run_until_complete(init())
	app.run(init())
	print("Bye Baby")

