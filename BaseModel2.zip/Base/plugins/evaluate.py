


from Base import app
from pyrogram import Client, filters
from pyrogram.errors import RPCError
from pyrogram.types import Message
from pyrogram.enums import ChatMemberStatus,ChatType, ParseMode

from importlib import import_module
import sys
from async_eval import eval
import asyncio


@Client.on_message(filters.command("EVAL", [".", "!", "?"]) & filters.me)
async def evaluate(client: Client, message: Message) :
	if len(message.command) == 1 :
		return await message.reply_text("Wrong of use command")
	global c, m
	c, m = client, message
	await message.edit("Processing...")
	text = message.text[6:]
	try :
		output = f"Result:- {eval(text)}"
	except Exception as e :
		output = f"Error:- {e}"
	toBeSent = f"Code:- `{text}`\n\n{output}"
	# print(len(str(toBeSent)))
	if len(str(toBeSent)) > 4095 :
		toBeSent = str(toBeSent)[:4000] + "\n\nToo long to send all content"
	print(len(str(toBeSent)))
	await message.edit(toBeSent, disable_web_page_preview=True, parse_mode=ParseMode.MARKDOWN)

@Client.on_message(filters.command('NEVAL', [".", "!", "?"]) & filters.me)
async def nEvaluate(client: Client, message: Message) :	
	if len(message.command) == 1 :
		return await message.reply_text("Wrong of use command")
	global c, m
	c, m = client, message
	await message.edit("Processing...")
	text = message.text[7:]
	try :
		output = eval(text)
		noError = True
	except Exception as e :
		output = f"Error:- {e}"
		noError = False
	if not noError :
		return await message.edit(f"Code:- `{text}`\n\n{output}", disable_web_page_preview=True, parse_mode=ParseMode.MARKDOWN)
	await message.delete()



@Client.on_message(filters.command("IMPORT", [".", "!", "?"]) & filters.me)
async def importModule(client: Client, message: Message) :
	if len(message.command) == 2 :
		module_name = message.command[1]
		try :
			globals()[module_name] = import_module(module_name)
			resp = f"Code:- <code>import {module_name}</code>\n\nResult:- Successfully imported {module_name}"
		except ModuleNotFoundError :
			resp = f"Code:- <code>import {module_name}</code>\n\nWarning:-  {module_name} module not found!"
		except Exception as e :
			resp = f"Code:- <code>import {module_name}</code>\n\nError:- {e}"
		await message.edit(resp)
	else :
		await message.edit(f"Wrong use of command")


@Client.on_message(filters.command("history", [".", "!", "?"]))
async def getHistory(client: Client, message: Message) :
	history = [x.id async for x in client.get_chat_history(message.chat.id)]
	await message.reply_text(history)


@Client.on_message(filters.command("stop", [".", "!"]) & filters.me)
async def stop(_, message) :
	await message.edit("Userbot Stopped")
	sys.exit("Exited..")
	
		
