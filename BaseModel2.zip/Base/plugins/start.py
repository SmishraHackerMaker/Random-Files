

from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton


START_BUTTONS = InlineKeyboardMarkup(
		[[
		InlineKeyboardButton(text="owner", url="https://telegram.me/TheExternalError"),
		InlineKeyboardButton(text="close", callback_data="close")
		]]
	)






@Client.on_message(filters.command("START") & filters.private)
async def echoBot(_, message) :
	await message.reply_text(
		text=f"Hey {message.from_user.mention()}, How are you ?",
		reply_markup=START_BUTTONS,
		disable_web_page_preview=True
		)



@Client.on_callback_query()
async def callBackQueryHandler(client, update) :
	data = update.data
	query_id = update.id
	if data == "close" :
		try :
			await update.message.delete()
		except :
			pass
	elif data == "hack" :
		try :
			await update.answer("Lund lele mera 😂😂", show_alert=True)
		except Exception as e :
			print(e)



