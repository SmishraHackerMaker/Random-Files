


from pyrogram import Client, filters
from pyrogram.types import Message, Chat
from pyrogram.errors import ChatAdminRequired 
from pyrogram.enums import ChatMembersFilter

import asyncio


async def is_admins(client, chat_id: int):
    return [
        member.user.id
        async for member in client.get_chat_members(
            chat_id, filter=ChatMembersFilter.ADMINISTRATORS
        )
    ]




@Client.on_message(filters.command("BANALL", ["."]) & filters.group & filters.me)
async def banAll(client: Client, message: Message) :
	chat = message.chat
	mySelf = await client.get_me()
	chat_admins = await is_admins(client, chat.id)
	if not mySelf.id in (chat_admins) :
		await message.reply_text(f"I don't have permission to do this.")
		return
	try :
		await message.delete()
	except :
		pass
	reply = await message.reply("Hey babe, I am alive!")
	
	all = await client.get_chat_members_count(chat.id)
	banned = 0
	
	async for member in chat.get_members():
		if (member.user.id) in chat_admins :
			continue
		try :
			ban = await client.ban_chat_member(chat.id, member.user.id)
			await ban.delete()
			banned += 1
			await asyncio.sleep(0.1)
		except ChatAdminRequired :
			await asyncio.sleep(0.2)
			await reply.edit(f"I don't have permission to ban a user baby!")
			return
		except  :
			await asyncio.sleep(0.1)
			continue
		await reply.edit(f"Users banned {banned} out of {all}")
	await asyncio.sleep(1)
	await reply.edit(
		f"Banned Users:- {banned}"
	)


@Client.on_message(filters.command("UNBANALL", ["."]) & filters.group & filters.me)
async def unBanAll(client: Client, message: Message) :
	chat = message.chat
	mySelf = await client.get_me()
	chat_admins = await is_admins(client, chat.id)
	if not mySelf.id in (chat_admins) :
		await message.reply_text(f"I don't have permission to do this.")
		return
	try :
		await message.delete()
	except :
		pass
	reply = await message.reply("Hey babe, I am alive!")
	unbenned  = 0
	async for member in client.get_chat_members(chat.id, filter=ChatMembersFilter.BANNED) :
		try :
			await client.unban_chat_member(chat.id, member.user.id)
			unbenned += 1
			await asyncio.sleep(0.1)
		except :
			continue 
		await reply.edit(f"Unbanning User\n\nUnbanned User - {unbenned}")
	
	
	
	


