

# from BaseModel2 import app
from pyrogram import Client

plugins = {
	'root': 'Base/plugins'
}


api_id: int = int(25367618)
api_hash: str = str("7c434192dd12bfb05089ec2c424ff11c")
session_string: str = str("BQGDFEIAt4d24UQ-zMUPW79JBsHMJVPFMwZykgdpj3X2GNpe3_mxJoc7hoKt2wqysr_ft9Bk373a_T-KcmbbvslzkcBmuUyx3TMLksNc7ifYiLyKQsIVpTEB0uCpQILT54eyX5RqVTTH4lWd16MYZhO5Cmu8wANNIWzofGi8BEq1QuNbSbddsQjfgwske92EWdjsJPxnwubsaVZ246s3MR1yDPT-HhmmoKhtPxSioQicyLp7IxGF_Wd7kE84xXqINBB6FDAqUEWk8ATST0aTdtehI2BfcOfktRZDgUpE4n1i_rTseJ76vLzX6HvedDD9eui1kbcul2tSOkTkxRxPZ0O3PLr3DgAAAAFLoeK_AA")
bot_token: str = str("5663105440:AAGXfx8L1DNCktQoZtVgGgbKLD3ymC0Sk-o")

app = Client(name="BaseModel2", api_id=api_id, api_hash=api_hash, session_string=session_string, plugins=plugins)
