

from pytgcalls import PyTgCalls
from pytgcalls.types import Update


from YMusic import call


@call.on_stream_end()
async def handler(client: PyTgCalls, update: Update):
	await stop(update.chat_id)


async def stop(chat_id):
	try :
		await call.leave_group_call(
			chat_id,
		)
	except :
		pass