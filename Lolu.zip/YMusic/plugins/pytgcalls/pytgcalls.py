

from pytgcalls import PyTgCalls, StreamType
from pytgcalls.types import Update
from pytgcalls.types.input_stream import AudioPiped
from pytgcalls.types.input_stream.quality import HighQualityAudio


from YMusic import call
from YMusic.utils.queue import QUEUE, get_queue, clear_queue, pop_an_item




async def _skip(chat_id) :
	if chat_id in QUEUE :
		chat_queue = get_queue(chat_id)
		if len(chat_queue) == 1 :
			await stop(chat_id)
			clear_queue(chat_id)
			return 1
		else :
			try :
				title = chat_queue[1][1]
				duration = chat_queue[1][2]
				songlink = chat_queue[1][3]
				link = chat_queue[1][4]
				await call.change_stream(
					chat_id,
					AudioPiped(
						songlink,
						HighQualityAudio(),
					),
					stream_type=StreamType().pulse_stream,
				)
				pop_an_item(chat_id)
				return [title, duration, link]
			except :
				return 2





@call.on_stream_end()
async def handler(client: PyTgCalls, update: Update):
	chat_id = update.chat_id
	resp = await _skip(chat_id)
	if resp == 1 :
		pass
	elif resp == 2 :
		await app.send_message("I got an error")
	else :
		await app.send_message(f"Playing Your Song\n\nSongName:- [{resp[0]}]({resp[2]})\nDuration:- {resp[1]}\nTime taken to play:- Unavailable", disable_web_page_preview=True)


async def stop(chat_id):
	try :
		await call.leave_group_call(
			chat_id,
		)
	except :
		pass




