from YMusic import app
from YMusic.core import userbot
from YMusic.utils import ytDetails
from YMusic.misc import SUDOERS
from YMusic.utils.roast.data import PORMS

from pyrogram import filters

import asyncio
import random
import time

import config


PLAY_COMMAND = ["PLAY", "SUNA"]

XPLAY_COMMAND = ["XVIDEO"]


PREFIX = config.PREFIX

RPREFIX = config.RPREFIX
        
async def ytdl(format: str, link: str):
    stdout, stderr = await bash(f'yt-dlp --geo-bypass -g -f "[height<=?720][width<=?1280]" {link}')
    if stdout:
        return 1, stdout
    return 0, stderr


async def bash(cmd):
    process = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await process.communicate()
    err = stderr.decode().strip()
    out = stdout.decode().strip()
    return out, err

  


async def processReplyToMessage(message):
	msg = message.reply_to_message
	if msg.audio or msg.voice :
		pass


    

async def playWithLinks(link):
	if "&" in link :
		pass
	if "?" in link :
		pass
	
	return 0





@app.on_message(filters.command(PLAY_COMMAND, PREFIX))
async def _aPlay(_, message) :
	start_time = time.time()
	if (message.reply_to_message) is not None :
		pass
	elif (len(message.command)) < 2 :
		await message.reply_text("You Forgot To Pass And Argument")
	else :
		m = await message.reply_text("Searching Your Query...")
		query = message.text.split(" ", 1)[1]
		title, duration, link = ytDetails.searchYt(query)
		await m.edit("Downloading...")
		format = "bestaudio"
		resp, ytlink = await ytdl(format, link)
		if resp == 0:
			await m.edit(f"❌ yt-dl issues detected\n\n» `{ytlink}`")
		else :
			# await asyncio.sleep(1)
			Status, Text = await userbot.playAudio(message.chat.id, ytlink)
			if Status == False :
				await m.edit(Text)
			else :
				if duration is None :
					duration = "Playing From LiveStream"
				finish_time = time.time()
				total_time_taken = str(int(finish_time - start_time)) + "s"
				await m.edit(f"Playing Your Song\n\nSongName:- [{title[:19]}]({link})\nDuration:- {duration}\nTime taken to play:- {total_time_taken}", disable_web_page_preview=True)



@app.on_message(filters.(PLAY_COMMAND, RPREFIX) & (filters.me | SUDOERS))
async def _xVideo(_, message):
	link = random.choice(REPLYRAID)
	Status, Text = await userbot.playVideo(message.chat.id, link)
	if Status == False :
		await message.reply_text(Text)
	try :
		message.delete()
	except :
		pass


