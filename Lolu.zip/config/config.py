


API_ID: int = int(25367618)

API_HASH: str = str("7c434192dd12bfb05089ec2c424ff11c")

SESSION_STRING: str = str("Your Session String Here")

OWNER_ID: list[int] = [5563867839, 1796596300, 971831558]

LOG_GROUP_ID: int = int(-1001781612088)

PREFIX: str = str(".")

RPREFIX: str = str("$")


# No Need To Edit Below This

LOG_FILE_NAME: str = "YMusic.txt"