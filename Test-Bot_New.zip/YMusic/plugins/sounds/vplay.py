
from YMusic import app
from YMusic.core import userbot

from pyrogram import filters

import asyncio

import config


VIDEO_PLAY = "VPLAY"

PREFIX = config.PREFIX

async def ytdl(link):
    proc = await asyncio.create_subprocess_exec(
        "yt-dlp",
        "-g",
        "-f",
        "best[height<=?720][width<=?1280]",
        f"{link}",
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await proc.communicate()
    if stdout:
        return 1, stdout.decode().split("\n")[0]
    else:
        return 0, stderr.decode()


@app.on_message(filters.command(VIDEO_PLAY, PREFIX))
async def _vPlay(_, message) :
	if (len(message.command)) < 2 :
		await message.reply_text("Sale Link To Dal De")
	else :
		m = message.reply_text("Downloading...")
		url = message.text.split(" ", 1)[1]
		veez, ytlink = await ytdl(url)
		if veez == 0:
			await loser.edit(f"❌ yt-dl issues detected\n\n» `{ytlink}`")
		else :
			Text = await userbot.playVideo(message.chat.id, ytlink)
			await message.reply_text(Text)
		




