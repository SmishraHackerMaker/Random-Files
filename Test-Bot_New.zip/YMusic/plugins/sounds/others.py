


from pyrogram import filters

from YMusic import app
from YMusic.core import userbot
import config



PREFIX = config.PREFIX

STOP_COMMAND = ["STOP", "CHUP"]


@app.on_message(filters.command(STOP_COMMAND, PREFIX))
async def _stop(_, message):
	try :
		Text = await userbot.stop(message.chat.id)
		await message.reply_text(Text)
	except Exception as e :
		return f"Error:- <code>{e}</code>"
