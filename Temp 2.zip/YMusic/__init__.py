
from YMusic.core.bot import YMusicBot #, YMusicUser
from .logging import LOGGER
from YMusic.misc import sudo

sudo()


app = YMusicBot()
#bot = YMusicUser(app)