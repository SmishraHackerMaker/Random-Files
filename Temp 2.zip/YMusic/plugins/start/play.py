
import random
import asyncio
from pyrogram import filters

from YMusic import app
import config


PREFIX = config.PREFIX

PLAY_COMMAND = ["PLAY", "SUNA"]


TEXT = ["LISTENING 🎧", "WHO ARE YOU", "WHAT ARE YOU DOING?", "ARE YOU KIDDING ME?", "HEY WHY ARE YOU NOT TALKING TO ME?", "BRO PLEASE LISTEN ME", "WHAT'S UP ?", "WHAT IS YOUR NAME?"]

@app.on_message(filters.command(PLAY_COMMAND, PREFIX))
async def _play(_, message):
	m = await message.reply_text("You Bro playing your music")
	for i in range(20) :
		choice = random.choice(TEXT)
		try :
			await m.edit(choice)
		except :
			pass
		await asyncio.sleep(5)
	await m.edit("Music Over")
