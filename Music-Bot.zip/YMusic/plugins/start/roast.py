


from pyrogram import filters
import random

from YMusic import app
from YMusic.core import userbot
import config
from YMusic.misc import SUDOERS
from YMusic.utils.roast.data import REPLYRAID

PREFIX = config.PREFIX

ROAST_COMMAND = "ROAST"


@app.on_message(filters.command(ROAST_COMMAND, PREFIX) & (filters.me | SUDOERS))
async def _fuck(_, message) :
	if message.reply_to_message_id is not None :
		try : 
			roastTime = int(message.text.split(" ", 1)[1])
		except :
			roastTime = 10
		chat_id = message.chat.id
		msg_id = message.reply_to_message_id
		for i in range(roastTime) :
			Text = random.choice(REPLYRAID)
			await send_msg(chat_id, msg_id, Text)
		await message.reply_text("Ho gya boss 🙂🙂")
	else :
		await message.reply_text("Abe roast kisko karna hai\nUsko tag karke ye command run kar")

	
async def send_msg(chat_id, msg_id, Text) :
	await app.send_message(
	    chat_id=chat_id,
	    text=Text,
	    reply_to_message_id=msg_id
	)	
		


