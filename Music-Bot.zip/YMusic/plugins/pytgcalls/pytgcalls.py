

from pytgcalls import PyTgCalls
from pytgcalls.types import Update


from YMusic.core import userbot
from YMusic import call


@call.on_stream_end()
async def handler(client: PyTgCalls, update: Update):
	try :
		await userbot.stop(update.chat_id)
	except :
		pass
