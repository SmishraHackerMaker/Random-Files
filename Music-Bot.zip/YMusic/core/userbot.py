from YMusic import call
from pytgcalls.types.input_stream import AudioPiped, AudioVideoPiped
from pytgcalls import StreamType
from pytgcalls.types.input_stream.quality import HighQualityAudio, HighQualityVideo


audio_file = "http://docs.evostream.com/sample_content/assets/sintel1m720p.mp4"


async def playAudio(chat_id, audio_file=audio_file):
	try :
		await call.join_group_call(
			chat_id,
			AudioPiped(
				audio_file,
				HighQualityAudio()
			),
			stream_type=StreamType().local_stream,
		)
		return "Success"
	except Exception as e :
		return f"Error:- <code>{e}</code>"



async def playVideo(chat_id, video_file=audio_file):
	try :
		await call.join_group_call(
			chat_id,
			AudioVideoPiped(
				video_file,
				HighQualityAudio(),
				HighQualityVideo(),
			),
			stream_type=StreamType().local_stream,
		)
		return "Success"
	except Exception as e :
		return f"Error:- <code>{e}</code>"



async def pause(chat_id):
	try:
		call.pause_stream(
			chat_id,
		)
	except Exception as e :
		return f"Error:- <code>{e}</code>"



async def resume(chat_id):
	try :
		call.resume_stream(
			chat_id,
		)
	except Exception as e :
		return f"Error:- <code>{e}</code>"


async def mute(chat_id):
	try :
		call.mute_stream(
			chat_id,
		)
	except Exception as e :
		return f"Error:- <code>{e}</code>"



async def unmute(chat_id):
	try :
		call.unmute_stream(
			chat_id,
		)
	except Exception as e :
		return f"Error:- <code>{e}</code>"


async def changeVolume(chat_id, volume: int=200):
	try :
		call.change_volume_call(
			chat_id,
			volume,
		)
	except Exception as e :
		return f"Error:- <code>{e}</code>"




async def stop(chat_id):
	try :
		await call.leave_group_call(
			chat_id,
		)
		return "Success"
	except Exception as e :
		return f"Error:- <code>{e}</code>"