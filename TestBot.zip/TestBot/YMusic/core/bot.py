
from pyrogram import Client
from pytgcalls import PyTgCalls

import config
from ..logging import LOGGER

api_id: int = config.API_ID
api_hash: str = config.API_HASH
session_string: str = config.SESSION_STRING


app = Client(name="YMusicBot", api_id=api_id, api_hash=api_hash, session_string=session_string)


call = PyTgCalls(app)




# class YMusicBot(Client):
	# def __init__(self) :
		# super().__init__(
			# name="YMusicBot",
			# api_id=api_id,
			# api_hash=api_hash,
			# session_string=session_string,
		# )
	
	# async def start(self):
		# await super().start()
		# get_me = await self.get_me()
		# self.username = get_me.username
		# self.id = get_me.id


# # class YMusicUser(PyTgCalls, YMusicBot) :
	# # def __init__(self):
		# # super().__init__(YMusicBot)
		
	# # async def start(self):
		# # LOGGER(__name__).info("Starting Bot + Assistant")
		# # await super().start()
		# # LOGGER(__name__).info("Successfully Started Both")