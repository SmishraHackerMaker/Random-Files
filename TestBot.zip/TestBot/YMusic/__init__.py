
from YMusic.core.bot import app, call #, YMusicUser
from .logging import LOGGER
from YMusic.misc import sudo

sudo()



