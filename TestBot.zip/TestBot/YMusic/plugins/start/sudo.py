

from pyrogram import filters
from YMusic import app
from YMusic.misc import SUDOERS
import config

SUDO_LIST = ["SUDOLIST"]
PREFIX = config.PREFIX

@app.on_message(
	filters.command(SUDO_LIST, PREFIX)
	& SUDOERS
)
async def _sudoCommand(_, message):
	sudo_users = ""
	for user_id in config.OWNER_ID:
		sudo_users += str(user_id) + "\n"
	await message.reply_text(sudo_users)
	
	
SUDO_ADD = ["SUDOADD"]

