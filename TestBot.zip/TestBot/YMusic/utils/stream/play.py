

from YMusic import call

from pytgcalls.types.input_stream import AudioPiped, AudioVideoPiped
from pytgcalls import StreamType


class Stream(call) :
	def __init__(self):
		pass
		
	async def playAudio(self, chat_id):
		pass
	
	async def pause(self, chat_id: int) -> str:
		audio_file = "http://docs.evostream.com/sample_content/assets/sintel1m720p.mp4"
		try :
			await self.join_group_call(
				chat_id,
				AudioPiped(
					audio_file,
				)
				stream_type=StreamType().pulse_stream,
			)
			return "Success"
		except Exception as e :
			return f"Error:- <code>{e}</code>")
	
	async def resume(self, chat_id: int) -> str:
		pass
	
	async def mute(self, chat_id: int) -> str:
		pass
	
	async def unmute(self, chat_id: int) -> str:
		pass
	
	async def volume(self, chat_id: int) -> str:
		pass
	
	async def stop(self, chat_id: int) -> str:
		try :
			await self.leave_group_call(
				chat_id,
			)
			return "Success"
		except Exception as e :
			return f"Error:- <code>{e}</code>")
	


userbot = Stream()